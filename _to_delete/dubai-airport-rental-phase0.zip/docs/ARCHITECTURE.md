# Architecture

## Business rules this architecture is built around

These were explicitly updated from the original business-model document
and MUST be respected by every future phase:

| Rule | Decision |
|---|---|
| **Website = Booking** | Customers book only through the website. There is no WhatsApp booking flow, and none of the schema, API, or UI should ever imply one. |
| **WhatsApp = Complaints/Support** | WhatsApp is used only for complaints, support, rental issues, and general communication during/after a rental. The `complaints` table is where those conversations get logged in the system; no booking table references WhatsApp. |
| **Customer = Provides Driver** | The company does not provide drivers. The `drivers` table captures driver details the *customer* supplies per booking. There is no company-driver assignment table anywhere in the schema. |
| **Coverage = Dubai Only** | `locations` has no emirate/country field — multi-region support is explicitly out of scope until a later "Expand" phase. |

## Customer journey (what the schema supports, not yet what's built)

```
Website
  → Select Dates
  → Select Location (Dubai only)
  → Select Pickup
  → Select Drop-off
  → Select Vehicle
  → Enter Customer/Driver Details
  → Payment
  → Booking Confirmation
  → Vehicle Handover
  → Rental
  → WhatsApp Support for Complaints
  → Vehicle Return
```

Phase 0 does not build this UI. It builds the `bookings`, `drivers`,
`payments`, `booking_status_history`, and `complaints` tables (plus RLS)
that this journey will read and write against in later phases.

## System overview

```
┌─────────────────────┐        ┌──────────────────────────┐
│   Frontend (Vite)    │        │  Supabase Edge Functions  │
│  React + TS + Tailwind│──────▶│  (service-role, TS/Deno)  │
│  uses ANON key only  │        │  privileged writes only   │
└──────────┬───────────┘        └─────────────┬────────────┘
           │  anon key + RLS                   │  service role key
           ▼                                   ▼
┌─────────────────────────────────────────────────────────────┐
│                Supabase (single backend platform)             │
│  PostgreSQL  ·  Auth  ·  Storage  ·  Row Level Security       │
└─────────────────────────────────────────────────────────────┘
```

**Why this shape, not a separate Node/Express API:** the whole backend
requirement is "use Supabase" — Postgres, Auth, and Storage cover almost
everything a booking platform needs directly from the client, with every
table protected by Row Level Security (see `supabase/migrations/`). The
handful of operations that must never trust the client directly —
confirming a payment, or an admin-only bulk action — run instead as
**Supabase Edge Functions** using the service-role key, which lives only
on the server side and is never shipped to the frontend. This avoids
standing up and hosting a second backend service for what is, at this
stage, a small set of privileged operations. If that set grows
substantially, revisit this decision — it is not irreversible.

## Frontend structure

```
src/
  lib/              Supabase client, typed env access — nothing else
  types/            Database types (mirrors the Supabase schema)
  features/
    booking/        Customer booking journey — NOT built yet (Phase 1+)
    admin/           Admin dashboard — NOT built yet (Phase 1+)
    shared/          Cross-cutting pieces (currently just the Phase 0 status screen)
```

`features/booking` and `features/admin` are placeholders on purpose —
Phase 0's job is the foundation underneath them, not the screens
themselves.

## Admin dashboard scope (for later phases)

The `admin_profiles` role foundation and RLS policies already support an
admin dashboard covering: vehicles/fleet, vehicle availability, bookings,
customers, customer-submitted driver information, payments, pricing,
pickup/handover, returns, complaints/support, reports, and system
settings. None of the UI for this exists yet.

## Security model

- **Row Level Security is mandatory on every table.** Nothing is
  readable or writable from the client except through an explicit RLS
  policy — see `supabase/migrations/20260824000000_phase0_foundation.sql`.
- **Two credential tiers:**
  - *Anon key* (public, `VITE_SUPABASE_ANON_KEY`) — used by the frontend.
    Every request still passes through RLS.
  - *Service role key* (`SUPABASE_SERVICE_ROLE_KEY`) — used only inside
    Edge Functions, bypasses RLS entirely, and must never be exposed to
    the frontend or committed to source control.
- **Driver documents are private.** The `driver-documents` Storage bucket
  is non-public; only the uploading customer (write) and admins (read)
  can touch it, enforced by storage policies, not just app logic. Vehicle
  images are the only public bucket.
- **Booking channel is enforced at the schema level.** `bookings.booking_channel`
  has a `check` constraint pinning it to `'website'` — a defensive measure
  so a future integration mistake can't silently insert a WhatsApp-sourced
  booking.
