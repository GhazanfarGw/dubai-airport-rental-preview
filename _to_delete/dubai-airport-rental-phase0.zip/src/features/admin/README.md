# Admin dashboard feature (not built yet)

This folder is a placeholder. The admin dashboard (fleet, bookings,
customers, driver documents, payments, pricing, pickup/handover, returns,
complaints/support, reports, settings) is scoped for a later phase,
against the domain foundation already in place in `supabase/migrations/`.

See `docs/ARCHITECTURE.md` for the full admin scope this will implement.
