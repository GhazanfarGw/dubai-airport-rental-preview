import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { FoundationStatus } from '@/features/shared/FoundationStatus'

/**
 * Phase 0 — Project Foundation & Architecture.
 *
 * This is intentionally a placeholder shell. No booking UI, no admin
 * dashboard, no payment flow lives here yet — those are built in later
 * phases against the domain foundation laid down in this phase
 * (see /supabase/migrations and /docs).
 */
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<FoundationStatus />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
