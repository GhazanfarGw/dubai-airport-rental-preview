/**
 * Hand-written placeholder for the Supabase-generated database types.
 *
 * Once this project is linked to a real Supabase project, replace this
 * file by running:
 *
 *   supabase gen types typescript --linked > src/types/database.ts
 *
 * Until then, this is kept in sync BY HAND with
 * supabase/migrations/20260824000000_phase0_foundation.sql — if you add a
 * column there, add it here too.
 */

export type AdminRole = 'super_admin' | 'staff'
export type VehicleStatus = 'available' | 'maintenance' | 'retired'
export type PricingTerm = 'daily' | 'weekly' | 'monthly' | '3_month'
export type BookingStatus = 'pending_payment' | 'confirmed' | 'active' | 'completed' | 'cancelled'
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'refunded'
export type ComplaintStatus = 'open' | 'in_progress' | 'resolved' | 'closed'
export type LocationType = 'airport' | 'city'

export interface Database {
  public: {
    Tables: {
      admin_profiles: {
        Row: {
          id: string
          full_name: string
          role: AdminRole
          created_at: string
        }
        Insert: {
          id: string
          full_name: string
          role?: AdminRole
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['admin_profiles']['Insert']>
      }
      customers: {
        Row: {
          id: string
          auth_user_id: string | null
          full_name: string
          email: string
          phone: string | null
          created_at: string
        }
        Insert: {
          id?: string
          auth_user_id?: string | null
          full_name: string
          email: string
          phone?: string | null
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['customers']['Insert']>
      }
      drivers: {
        Row: {
          id: string
          booking_id: string
          full_name: string
          date_of_birth: string
          license_number: string
          license_country: string
          license_expiry: string
          license_document_path: string | null
          id_document_path: string | null
          created_at: string
        }
        Insert: {
          id?: string
          booking_id: string
          full_name: string
          date_of_birth: string
          license_number: string
          license_country: string
          license_expiry: string
          license_document_path?: string | null
          id_document_path?: string | null
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['drivers']['Insert']>
      }
      vehicle_categories: {
        Row: {
          id: string
          name: string
          description: string | null
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['vehicle_categories']['Insert']>
      }
      vehicles: {
        Row: {
          id: string
          category_id: string
          make: string
          model: string
          model_year: number
          transmission: string
          seats: number
          plate_number: string
          status: VehicleStatus
          created_at: string
        }
        Insert: {
          id?: string
          category_id: string
          make: string
          model: string
          model_year: number
          transmission?: string
          seats?: number
          plate_number: string
          status?: VehicleStatus
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['vehicles']['Insert']>
      }
      vehicle_images: {
        Row: {
          id: string
          vehicle_id: string
          storage_path: string
          is_primary: boolean
          sort_order: number
          created_at: string
        }
        Insert: {
          id?: string
          vehicle_id: string
          storage_path: string
          is_primary?: boolean
          sort_order?: number
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['vehicle_images']['Insert']>
      }
      pricing: {
        Row: {
          id: string
          vehicle_id: string
          term: PricingTerm
          list_price: number
          client_price: number
          currency: string
          created_at: string
        }
        Insert: {
          id?: string
          vehicle_id: string
          term: PricingTerm
          list_price: number
          client_price: number
          currency?: string
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['pricing']['Insert']>
      }
      locations: {
        Row: {
          id: string
          name: string
          type: LocationType
          is_active: boolean
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          type: LocationType
          is_active?: boolean
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['locations']['Insert']>
      }
      bookings: {
        Row: {
          id: string
          customer_id: string
          vehicle_id: string
          pickup_location_id: string
          dropoff_location_id: string
          term: PricingTerm
          start_date: string
          end_date: string
          status: BookingStatus
          total_price: number
          currency: string
          booking_channel: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          customer_id: string
          vehicle_id: string
          pickup_location_id: string
          dropoff_location_id: string
          term: PricingTerm
          start_date: string
          end_date: string
          status?: BookingStatus
          total_price: number
          currency?: string
          booking_channel?: string
          created_at?: string
          updated_at?: string
        }
        Update: Partial<Database['public']['Tables']['bookings']['Insert']>
      }
      booking_status_history: {
        Row: {
          id: string
          booking_id: string
          old_status: BookingStatus | null
          new_status: BookingStatus
          changed_by: string | null
          changed_at: string
        }
        Insert: {
          id?: string
          booking_id: string
          old_status?: BookingStatus | null
          new_status: BookingStatus
          changed_by?: string | null
          changed_at?: string
        }
        Update: Partial<Database['public']['Tables']['booking_status_history']['Insert']>
      }
      payments: {
        Row: {
          id: string
          booking_id: string
          amount: number
          currency: string
          status: PaymentStatus
          provider: string
          provider_reference: string | null
          paid_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          booking_id: string
          amount: number
          currency?: string
          status?: PaymentStatus
          provider: string
          provider_reference?: string | null
          paid_at?: string | null
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['payments']['Insert']>
      }
      complaints: {
        Row: {
          id: string
          booking_id: string | null
          customer_id: string
          subject: string
          description: string
          status: ComplaintStatus
          created_at: string
          resolved_at: string | null
        }
        Insert: {
          id?: string
          booking_id?: string | null
          customer_id: string
          subject: string
          description: string
          status?: ComplaintStatus
          created_at?: string
          resolved_at?: string | null
        }
        Update: Partial<Database['public']['Tables']['complaints']['Insert']>
      }
      audit_logs: {
        Row: {
          id: string
          actor_id: string | null
          action: string
          entity_table: string
          entity_id: string | null
          metadata: Record<string, unknown>
          created_at: string
        }
        Insert: {
          id?: string
          actor_id?: string | null
          action: string
          entity_table: string
          entity_id?: string | null
          metadata?: Record<string, unknown>
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['audit_logs']['Insert']>
      }
    }
  }
}
